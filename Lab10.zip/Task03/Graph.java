// name: mohammed alkhnani
// id: 201954190

import java.util.*;

//Determines if a vertex is reachable from another vertex in a directed graph
public class Graph {
 private List<List<Integer>> adjList = null;
 private int numVertices;

 public Graph(List<Edge> edges, int numVertices) {
     this.numVertices = numVertices;
     adjList = new ArrayList<>();

     for (int i = 0; i < numVertices; i++) {
         adjList.add(new ArrayList<>());
     }

     // add edges to the directed graph
     for (Edge edge : edges) {
         int src = edge.source;
         int dest = edge.dest;

         adjList.get(src).add(dest);
     }
 }

 public boolean isReachable(int src, int dest) {
     boolean[] visited = new boolean[numVertices];
     return isReachable(src, dest, visited);
 }

 // Function to perform BFS traversal from the source vertex in the graph to
 // determine if the destination vertex is reachable from the source or not
 private boolean isReachable(int src, int dest, boolean[] visited) {
	// to be completed by students 
     Stack<Integer> stack = new Stack<>();
     stack.push(src);

     while (!stack.empty()) {
         src = stack.pop();
         if (!visited[src])
             visited[src] = true;
         Iterator<Integer> itr = adjList.get(src).iterator();
         while (itr.hasNext()) {
             int v = itr.next();
             if (!visited[v])
                 stack.push(v);
         }
     }

     if (visited[dest])
         return true;
     else
         return false;
 }
}
