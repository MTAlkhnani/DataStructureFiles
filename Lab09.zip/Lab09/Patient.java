//name: mohammed alkhnani
//ID: 201954190
public class Patient implements Comparable<Patient>{
	private String name; 
	private int priorityQueue; 

	public Patient(String name, int level){
		this.name = name; 
		this.priorityQueue = level; 
	}
	public int compareTo(Patient o){
		if (this.priorityQueue > o.priorityQueue)
			return 1; 
		else if (this.priorityQueue == o.priorityQueue)
			return 1;
		else
			return -1; 
	}
	@Override
	public String toString(){
		return "Patient Name>> "+name+", Emergency Level>> "+priorityQueue; 
	}
}
