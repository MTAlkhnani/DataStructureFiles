

import java.util.Arrays;

//name: mohammed alkhnani
//ID: 201954190

public class Test {
	public static void main(String[] args) {
		//    	 testing you methods in part1 by constructing a heap in two ways
		System.out.println("****************Part 1: ****************");
		Integer[] a = {10, 2, 8, 9, 1, 6, 3, 4, 0, 5};
		//Integer[] a = {4, 3, 2}; //Small Test
		// build bottom up
		System.out.println("****building bottom up****");
		BinaryHeap bh = new BinaryHeap(a, false);
		System.out.println("\nThe heap is: "+bh);
		System.out.println("\nSorted Array is: "+Arrays.toString(bh.heapSort()));
		System.out.println();
		// build top down
		System.out.println("****building top down****");
		bh = new BinaryHeap(a, true);
		System.out.println("\nThe heap is: "+bh);
		System.out.println("\nSorted Array is: "+Arrays.toString(bh.heapSort()));
		System.out.println();

		// Part 2 test Patient class
		System.out.println("****************Part 2: ****************");
		// Create an array of 10 Patient(s) using the names in the below array and random levels of emergency
		String[] names = {"Ali", "Hamad", "Careem", "Gamal", "Emad", "Fahad", "Dafer", "Bader", "Ibrahim", "Javeed"};

		Patient[] patients = new Patient[names.length];
		for (int i = 0; i < names.length; i++) {
			int level = (int) (Math.random() * 5) + 1;
			patients[i] = new Patient(names[i], level);
		}

		System.out.println("The original order of patients arrival is>> ");
		for (Comparable<Patient> i : patients)
			System.out.println(i);


		BinaryHeap heap = new BinaryHeap(patients.length);   


		for (int i = 0; i< patients.length; i++)
			heap.enqueue(patients[i]);
		
		Comparable<Patient>[] sortedheap = heap.heapSort();
		System.out.println("\nThe TREATMENT order of patients is>> ");
		for (Comparable<Patient> i : sortedheap)
			System.out.println(i);
	}
}

