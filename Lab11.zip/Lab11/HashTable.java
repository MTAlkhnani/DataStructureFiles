

//Name: Mohammed Alkhnani
//ID: 201954190
public class HashTable<T> {
	
	Entry<T> [] entry;
	int occupied = 0;
	int size;
	
	
	public HashTable(int size) {
		this.size = size;
		entry = new Entry[size];
		for(int i = 0; i < size; i++)
			entry[i] = new Entry<T>();
	}
	
	public boolean insert(T dataObject) {
		int i = (dataObject.hashCode() % size) % size;
		if (occupied == size)
			return false;
		else if (entry[i].status.equals("E") || entry[i].status.equals("D")) {
			entry[i].dataObject = dataObject;
			entry[i].status = "O";
			occupied += 1;
			return true;
		}
		else {
			i = findNextAvailableSlot(i);
			entry[i].dataObject = dataObject;
			entry[i].status = "O";
			occupied += 1;
			return true;
		}			
	}
	
	public int findNextAvailableSlot(int currentSlot) {
		int i = ((currentSlot + 1) % size);
		if (entry[i].status.equals("E") || entry[i].status.equals("D"))
			return i;
		else
			return findNextAvailableSlot (i);
		}
	
	
	
	public boolean delete(T dataObject) {
		int i = ((dataObject.hashCode() % size) % size);
		if (entry[i].status.equals("O") || entry[i].dataObject.equals(dataObject)) {
			entry[i].status = "D";
			occupied -= 1;
			return true;
			}
		else if (entry[i].status.equals("E") || entry[i].status.equals("D"))
			return false;
		else
			return deleteAUX(dataObject, i+1);
	}

	private boolean deleteAUX(T dataObject, int idx) {
		int i = (idx) % size;
		if (entry[i].status.equals("O") || entry[i].dataObject.equals(dataObject)) {
			entry[i].status = "D";
			occupied -= 1;
			return true;
			}
		else if (entry[i].status.equals("E") || entry[i].status.equals("D"))
			return false;
		else
			return deleteAUX(dataObject, i+1);
	}
	
	public int find(T dataObject) {
		int i = ((dataObject.hashCode() % size) % size);
		if (entry[i].status.equals("E"))
			return -1;			
		else {
			if(entry[i].dataObject.equals(dataObject)) {
				if(entry[i].status.equals("D"))
					return -1;
				else
					return i;
				}
			else
				return findAUX(dataObject, i+1);
		}
	}

	private int findAUX(T dataObject, int idx) {
		int i = ((idx) % size);
		if (entry[i].status.equals("E") || entry[i].status.equals("D"))
			return -1;			
		else {
			if(entry[i].dataObject.equals(dataObject)) {
				if(entry[i].status.equals("D"))
					return -1;
				else
					return i;
				}
			else
				return findAUX(dataObject, i+1);
		}
	}
	
	public String toString() {
		String table = "";
		for (int i = 0; i < size; i++)
			table += i+":  ["+entry[i].dataObject+", '"+entry[i].status+"']\n";
		return table;
	}

}
