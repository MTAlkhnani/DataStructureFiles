
//Name: Mohammed Alkhnani
//ID: 201954190
public class Entry<T> {
	
	T dataObject = null;
	String status = "E";
	
	public String toString() {
		return dataObject.toString();		
	}
	public int getHashCode() {
		return dataObject.hashCode();
	}
	
}
