
//Name: Mohammed Alkhnani
//ID: 201954190
public class Main {

	public static void main(String[] args) {
		
		HashTable<Integer> hash = new HashTable<>(13);
		int [] array = {18,26,35,9};
		
		for(int i = 0; i < array.length; i++)
			hash.insert(array[i]);
		System.out.println("After inserting 18, 26, 35 and 09,\nhashtable is");
		System.out.println(hash.toString());
		
		

		if(hash.find(15) == -1) 
			System.out.println("15 not found");
		else 
			System.out.println("15 found at " + hash.find(15));
		if(hash.find(48) == -1) 
			System.out.println("48 not found");
		else 
			System.out.println("48 found at " + hash.find(48));
		
		

		if(hash.delete(35)) 
			System.out.println("35 successfully deleted");
		else 
			System.out.println("35 not deleted");
		
		
		
		if(hash.find(9) == -1) 
			System.out.println("9 not found");
		else 
			System.out.println("9 found at " + hash.find(9));
		
		
		hash.insert(64);
		hash.insert(47);
		System.out.println("\nAfter deleting 35 and inserting 64 and 47,\nhashtable is");
		System.out.println(hash.toString());
		
		
		if(hash.find(35) == -1) 
			System.out.print("35 not found");
		else 
			System.out.println("35 found at " + hash.find(35));
	}

}
