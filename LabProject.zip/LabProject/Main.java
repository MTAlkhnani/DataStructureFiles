

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Main {
	
    public static void main(String args[]) throws FileNotFoundException{
    	Trie trie = new Trie();
    	Scanner sc = new Scanner(System.in);
    	String AllWords= "";
    	while (true) {
    	  System.out.println("TRIE PROJECT: Enter your choice?\n1) Create an empty trie\n2) Create a trie with initial letters\n3) Insert a word\n4) Delete a word\n5) List all words that begin with a prefix\n6) Size of the trie\n7) End");
    	  String input = sc.nextLine();
    	  switch (input)
    	  {
    	      case "1":
    	          trie = new Trie();
    	          System.out.println("Trie Created!");
    	          break;
    	      case "2":
    	          //sc.nextLine();
    	          trie = new Trie();
    	          System.out.print("Enter your list of letters> ");
    	          String[] inputList = sc.nextLine().split(" ");
    	          String completeWord = "";
    	          for (String inp: inputList)
    	          {
    	              completeWord += inp;
    	          }
    	          if (validate(completeWord))
    	          {
    	              String Totallines[] = printPermutn(completeWord,"").split("\\r?\\n");
    	              for(int i=0;i<Totallines.length;i++)
    	              {
    	                  if(validate(Totallines[i]))
    	                  {
    	                      trie.insert(Totallines[i]);
    	                  }
    	              }

    	              for(int i=1;i<completeWord.length();i++)
    	              {
    	                  String TL[] = printPermutn(completeWord.substring(i),"").split("\\r?\\n");
    	                  for(int j=0;j<TL.length;j++)
    	                  {
    	                      //System.out.println(TL[j]);
    	                      if(validate(TL[j]))
    	                      {
    	                          AllWords +=TL[j]+"\n";
    	                          trie.insert(TL[i]);
    	                      }
    	                  }
    	              }
    	              System.out.println("Trie Created!");
    	          }
    	          else
    	          {
    	              System.out.println("Trie not Created!");
    	          }
    	          break;
    	      case "3":
    	          //sc.nextLine();
    	          System.out.print("Enter the word: ");
    	          trie.insert(sc.nextLine());
	              System.out.println("Word is inserted!");
    	          break;
    	      case "4":
    	          System.out.print("Enter the word: ");
    	          trie.delete(sc.nextLine());
	              System.out.println("Word is deleted!");
    	          break;
    	      case "5":
    	          System.out.print("Enter the prefix: ");
    	          String prefix = sc.nextLine();
    	          String Totallines[] = AllWords.split("\\r?\\n");
    	          Totallines = Arrays.stream(Totallines).distinct().toArray(String[]::new);
    	          for(int i=0;i<Totallines.length;i++)
    	          {
    	              if(Totallines[i].startsWith(prefix))
    	              {
    	                  System.out.println(Totallines[i]);
    	              }
    	          }
    	              break;

    	      case "6":
    	          System.out.println("Size of trie: " + trie.size());
    	          break;
    	      case "7":
    	          System.exit(0);
    	      default:
    	          System.out.println("Invalid Choice");
    	          break;
    	  }
    	}
    	}

    	static String Permutations = "";
    	static String printPermutn(String str, String ans)
    	{

    	// If string is empty
    	if (str.length() == 0)
    	{
    		Permutations += ans+"\n";
    		return "";
    	}

    	for (int i = 0; i < str.length(); i++) {

    		// ith character of str
    		char ch = str.charAt(i);

    		// Rest of the string after excluding
    		// the ith character
    		String ros = str.substring(0, i) + str.substring(i + 1);

    		// Recurvise call
    		printPermutn(ros, ans + ch);
    	}
    	return Permutations;
    	}
    	public static boolean validate(String word) throws FileNotFoundException {
    	String s = "";
    	Scanner file = new Scanner(new File("C:\\trie_project\\dictionary.txt")).useDelimiter(",\\s*");
    	List<String> temps = new ArrayList<String>();
    	while (file.hasNext())
    	{
    		s = file.next();
    		temps.add(s);
    	}
    	file.close();
    	boolean flag = false;
    	String[] tempArray = temps.toArray(new String[0]);
    	String lines[] = tempArray[0].split("\\r?\\n");
    	for(int i=0;i<lines.length;i++)
    	{
    		if(lines[i].equals(word))
    		{
    			flag = true;
    		}
    	}
    	return flag;
    	}
}
