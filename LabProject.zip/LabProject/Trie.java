

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;

public class Trie {
	protected final int ALPHABET_SIZE = 26;
	protected TrieNode root = new TrieNode(' ');
	protected int size = 0;
	
	public int size() {
		return size;
	}

	public void insert(String word) {
		word = word.toUpperCase();
		TrieNode current = root;
		for(char ch : word.toCharArray()) {
			int index = ch - 'A';
			if(current.children[index] == null) {
				current.children[index] = new TrieNode(ch);
				size++;
			}
			current = current.children[index];
			current.isEndOfWord = false;	
		}
		current.isEndOfWord = true;
	}

	public Boolean contains(String s) {
		s = s.toUpperCase();
		TrieNode current = root;
		int index;
		for (int i = 0; i < s.length(); i++)
		{
			index = s.charAt(i) - 'A';

			if (current.children[index] == null)
				return false;

			current = current.children[index];
		}
		return (current.isEndOfWord);
	}


	public boolean isEmpty(){
		TrieNode current = root;
		for (int i = 0; i < ALPHABET_SIZE; i++)
			if (current.children[i] != null)
				return false;
		return true;
	}

    public void clear() {
		TrieNode current = root;
		for (int i = 0; i < ALPHABET_SIZE; i++)
			if (current.children[i] != null)
				current.children[i] = null;
    }
    
    private boolean hasChildren(TrieNode current) {
		for (int i = 0; i < ALPHABET_SIZE; i++)
			if (current.children[i] != null)
				return true;
		return false;
    }
    
	public Boolean isPrefix(String s) {
		s = s.toUpperCase();
        TrieNode current = root;
        for (int i = 0; i < s.length(); ++i) {
            current = current.children[s.charAt(i) - 'A'];
            if (current == null)
                return false;
        }
        if(current.isEndOfWord && hasChildren(current))
        	return true;
        else
        	return false;
	}
	public void delete(String s) {
		s = s.toUpperCase();
		delete(root, s, 0);
	}
    public void delete(TrieNode current, String s, int i){
        // If tree is empty
    	s = s.toUpperCase();
        if (current == null)
            return;
        if (i == s.length()) {
            if (current.isEndOfWord)
            	current.isEndOfWord = false;
            if (!hasChildren(current)) {
            	current = null;
                size--;
            }
            return;
        }
        int index = s.charAt(i) - 'A';
        delete(current.children[index], s, i + 1);
        if (!hasChildren(current) && current.isEndOfWord == false){
        	current = null;
            size--;
        }
        return;
    }

    public String[] allWordsPrefix(String p){
    	p = p.toUpperCase();
        TrieNode current = root;
        if (!isPrefix(p))
            return new String[0];
        ArrayList<String> found = new ArrayList<>();
        Stack<TrieNode> s1 = new Stack<>();
        Stack<String> s2 = new Stack<>();
        for (int i = 0; i < p.length(); ++i)
            current = current.children[p.charAt(i) - 'A'];
        s1.push(current);
        s2.push(p);
        System.out.println("Prefix: "+p);
        while (!s1.empty() && !s2.empty()) {
            current = s1.pop();
            p = s2.pop();
            if (current.isEndOfWord)
                found.add(p);
            int cnt = 0;
            for (TrieNode child: current.children) {
                if (child != null) {
                    s1.push(child);
                    s2.push(p + ((char) ('A' + cnt)));
                }
                cnt++;
            }
        }
        return Arrays.copyOf(found.toArray(), found.size(), String[].class);
    }
}
