
public class TrieNode {
	protected final int ALPHABET_SIZE = 26;
	protected char value;
	protected TrieNode[] children = new TrieNode[ALPHABET_SIZE];
	protected Boolean isEndOfWord;

	public TrieNode(char value) {
		this.value = value;
	}
	
}
