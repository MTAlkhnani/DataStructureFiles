
public class Main {

	public static void main(String[] args) {
		System.out.println("GCD method: "+GCD(45, 25));
		String[] fruits = {"Apple", "Mango", "Banana", "Orange", "Peach", "Lime", "Watermelon"};
		System.out.println();
		System.out.println("Longest fruit: "+findLongest(fruits, 0));
		System.out.println("Shortest fruit: " + findSmallest(fruits, 0));
		System.out.println();
		System.out.println("1234567 after commas: " + putCommas("1234567"));
		System.out.println();
		System.out.println("level after the isPalindrome test: " + isPalindrome("level"));
		System.out.println("wow after the isPalindrome test: " + isPalindrome("wow"));
		System.out.println("lever after the isPalindrome test: " + isPalindrome("lever"));
	}



    public static String findSmallest(String[] array, int index) {
        if (index == array.length - 1) {
            return array[index];
        } 
        
        else {
            String result = findSmallest(array, index + 1);
            if (array[index].length() < result.length())
                result = array[index];
            return result;
        }
    }

    public static String findLongest(String[] array, int index) {
        if (index == array.length - 1) {
            return array[index];
        }
        
        else {
            String result = findLongest(array, index + 1);
            if (array[index].length() > result.length())
                result = array[index];
            return result;
        }
    }
	   
	public static int GCD(int n, int m) {
		if (m == 0)
			return n;
		else
			return GCD(m, n % m);
	}
	
	public static String putCommas(String x) {
		if (x.length() <= 3) 
			return x;
		else {
			return putCommas(x.substring(0,x.length()-3)) + "," + x.substring(x.length()-3);
		}
		
	}
	
	public static boolean isPalindrome(String word) {
		if (word.length() == 0 || word.length() == 1) //because if it is 0 or 1 then it is palindrome
			return true;
		else if (word.substring(0,1).equals(word.substring(word.length()-1, word.length()))) {
			return isPalindrome(word.substring(1, word.length()-1));
		}
		else
			return false;
	}
}
