package Lab01;

class Graduate extends Student{

	Graduate(int ID, double GPA) {
		super(ID, GPA);
	}
	
	@Override
	public String getStatus() {
		if (getGPA() >= 3) {
			return "good";
		}
		else {
			return "probation ";
		}
	}

}
