package Lab01;

import java.util.Random;

public class Main {

	public static void main(String[] args) {
		
		Random rand = new Random();
		
		Student[] student = new Student[10];
		
		//Students IDs and GPAs generation
		String[] GPAs = new String[10];
		String[] IDs = new String[10];
		for (int i = 0; i < 10; i++) {
			GPAs[i] = String.format("%.2f", 0 + (4 - 0) * rand.nextDouble());
			IDs[i] = "201"+ String.format("%05d", rand.nextInt(100000))+ "0";
		}
		
		//displaying students
		for (int i = 0; i < 5; i++) {
			student[i] = new Undergraduate(Integer.parseInt(IDs[i]),Double.parseDouble(GPAs[i]));
			System.out.println("Undergraduate " + student[i].displayStudent());
		}
		for (int i = 5; i < 10; i++) {
			student[i] = new Graduate(Integer.parseInt(IDs[i]),Double.parseDouble(GPAs[i]));
			System.out.println("Graduate " + student[i].displayStudent());
		}
	}
}