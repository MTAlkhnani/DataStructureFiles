package Lab01;

abstract class Student {
	private int ID;
    private double GPA;
	
	Student(int ID, double GPA){
		this.ID = ID;
		this.GPA = GPA;
	}
	public abstract String getStatus();
	
	public final String displayStudent() {
		return "ID>> "+ID+", GPA>> "+GPA+", Status>> "+getStatus();
	}
	public final double getGPA() {
		return GPA;
	}
}


