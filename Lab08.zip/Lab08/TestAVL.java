

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

//name: mohammed alkhnani
//id: 201954190


public class TestAVL {
	public static void main(String[] args) throws FileNotFoundException {
		// Example which works with Left Rotation
		AVLTree<String> t = new AVLTree<String>();
		for (int i = 5; i >= 1; i--) {
			t.insertAVL("a" + i);
			System.out.print("After inserting the element a" + i + ", bfs is>> ");
			t.breadthFirst();
			System.out.println("\n====================");
		}
		System.out.print("Finally, bfs is>> ");
		t.breadthFirst();
		System.out.println("\n====================");


		// Exercise 2
		System.out.println();
		System.out.println("Exercise 2");
		System.out.println();
		int[] values = { 8, 14, 12, 18, 23, 20, 15, 13, 7, 16 };
		// TODO Complete the code here to solve exercise 2 in a similar fashion as the code above 
		// you should print the result of BFS of the AVL tree after each insertion



		// TODO Now delete the following elements: 15 16 13, and print BFS after each deletion
		AVLTree<Integer> tt = new AVLTree<Integer>();
		for (int i = 0; i < values.length; i++) {
			tt.insertAVL(values[i]);
			System.out.print("After inserting the element " + values[i] + ", bfs is>> ");
			tt.breadthFirst();
			System.out.println("\n====================");
		}

		System.out.println();

		tt.deleteAVL(15);
		System.out.print("\nAfter deleting the element 15, bfs is>> ");
		tt.breadthFirst();
		tt.deleteAVL(16);
		System.out.print("\nAfter deleting the element 16, bfs is>> ");
		tt.breadthFirst();
		tt.deleteAVL(13);
		System.out.print("\nAfter deleting the element 13, bfs is>> ");
		tt.breadthFirst();
		System.out.println();


		System.out.println();
		System.out.println("Exercise 3");
		System.out.println();
		// TODO read the text file, insert unique words into the AVL tree and print its
		// inorder traversal
		AVLTree<String> exe3 = new AVLTree<String>();
		File file = new File("C:\\sampletextfile.txt");
		Scanner scanner = new Scanner(System.in);
		Scanner readFile = new Scanner(file);

		String words;
		readFile.next();
		while(readFile.hasNextLine()) {
			words = readFile.next();
			if(!exe3.isInTree(words)) {
				exe3.insert(words);
			}
			readFile.next();

		}
		readFile.close();
		exe3.inorder();


	}
}
