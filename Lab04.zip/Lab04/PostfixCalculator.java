//package Lab04;

import java.util.Arrays;
import java.util.Scanner;

public class PostfixCalculator {
	public static int calculatePostfix(String text) { 
		LabStack<String> stack1 = new LabStack<String>();
		int result = 0;
		int a1 = 0;
		int a2 = 0;
		String[] array = text.split(" ");
		System.out.println(Arrays.toString(array));
		try {
			for (int i = 0; i < array.length; i++) { 
				String c = array[i]; 
				if (isDigit(c)) { 
					stack1.push(""+c); 
				}
				else if (c.equals("+")) {
					a1 = Integer.parseInt(stack1.pop());
					a2 = Integer.parseInt(stack1.pop());
					result = a2 + a1;
					stack1.push(""+result);
					System.out.println("Currently, the stack is >> "+stack1);
				}
				else if (c.equals("-")) {
					a1 = Integer.parseInt(stack1.pop());
					a2 = Integer.parseInt(stack1.pop());
					result = a2 - a1; 
					stack1.push(""+result);
					System.out.println("Currently, the stack is >> "+stack1);
				}
				else if (c.equals("/")) {
					a1 = Integer.parseInt(stack1.pop());
					a2 = Integer.parseInt(stack1.pop());
					result = a2 / a1; 
					stack1.push(""+result);
					System.out.println("Currently, the stack is >> "+stack1);
				}
				else if (c.equals("*")) {
					a1 = Integer.parseInt(stack1.pop());
					a2 = Integer.parseInt(stack1.pop());
					result = a2 * a1; 
					stack1.push(""+result);
					System.out.println("Currently, the stack is >> "+stack1);
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Your postfix is not valid");
			System.exit(0);
		}
		System.out.print(text + " = ");
		return Integer.parseInt(stack1.pop());
	}


	public static boolean isDigit(String str){
		for (char c : str.toCharArray()){
			if (!Character.isDigit(c)) return false;
		}
		return true;
	}


	public static void main(String[] args) {

		System.out.print("Enter your <postfix> expression: "); 
		Scanner input = new Scanner(System.in);
		String text = input.nextLine();
		System.out.println(calculatePostfix(text)); 
		input.close();
	}
}
