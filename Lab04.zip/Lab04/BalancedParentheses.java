//package Lab04;

import java.util.Scanner;

public class BalancedParentheses {
	public static boolean isParenthesesBalanced(String text) { 
		LabStack<String> stack1 = new LabStack<String>();
		int counter = 0;// so if counter is 0 then there is no parentheses therefore return false
		for (int i = 0; i < text.length(); i++) { 
			char c = text.charAt(i); 

			if (c == '(' || c == '[' || c == '{') { 
				stack1.push(""+c); 
				counter++;
			}
			else if (c == ')' || c == ']' || c == '}') {
				if (stack1.isEmpty())
					return false;
				String compare =""+ stack1.topEl() + c;
				
				if (compare.equals("()") || compare.equals("{}") || compare.equals("[]")) {
					stack1.pop();
				}
			}
		}
		if (counter == 0)
			return false;
		else
			return stack1.isEmpty();

	} 
	public static void main(String[] args) {
		
		System.out.print("Enter your expression: "); 
		Scanner input = new Scanner(System.in);
		String text = input.nextLine();
		// Function call
		if (isParenthesesBalanced(text))
			System.out.println("Expression is Balanced"); 
		else
			System.out.println("Expression is not Balanced "); 
		input.close();
	} 

}
