//package Lab04;

import java.util.Scanner;

public class ReverseQ {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		LabStack<String> stack1 = new LabStack<String>();
		System.out.print("Enter your input: ");

		String values[] = input.nextLine().split(" ");
		for (String str : values) {
			stack1.push(str);
		}
		
		System.out.println("Now the stack is>> " + stack1);

		LabQueue<String> queue1 = new LabQueue<String>();

		while (!stack1.isEmpty()) {
			queue1.enqueue(stack1.pop());
		}

		while (!queue1.isEmpty()) {
			stack1.push(queue1.dequeue());
		}
		System.out.println("After Reverse the stack is>> " + stack1);
		input.close();
	}
}