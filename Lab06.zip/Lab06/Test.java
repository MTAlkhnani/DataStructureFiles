

// name: mohammed alkhnani
// id: 201954190

public class Test {

	public static void main(String[] args) {
		BST<Integer> test = new BST<Integer>();

		test.insert(15);
		test.insert(12);
		test.insert(6);
		test.insert(7);
		test.insert(14);
		test.insert(20);
		test.insert(40);
		test.insert(16);

		
		System.out.println("The number of nodes are: " + test.count());
		System.out.println("The number '6' is leaf? " + test.isLeaf(6));
		System.out.println("The number '7' is leaf? " + test.isLeaf(7));
		System.out.println("The number of leaves are: " + test.countLeaves());
		System.out.println("The height is: " + test.height());

		
		System.out.println("\nThe various traversals are: ");
		System.out.print("Breadth-First traversal prints: ");
		test.breadthFirst();
		System.out.print("\nPreorder Depth First Traversal prints: ");
		test.preorder();
		System.out.print("\nInorder Depth First Traversal prints: ");
		test.inorder();
		System.out.print("\nPost Order Depth First Traversal prints: ");
		test.postorder();
		
	}

}
